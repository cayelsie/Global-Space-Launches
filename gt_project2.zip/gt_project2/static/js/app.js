function buildCharts(new_country){
//Setting up for the flask url
var url = "./finaldata.json";
//Read the json file   
    d3.json(url).then((data) => {
        console.log(data);

        var filter_data = data.filter(item=>{
            return item.CompanysCountryofOrigin == new_country;
        })

        console.log(filter_data)
        /* var inputFields = document.getElementsByClassName("filter-value")
        console.log(inputFields);

        for(var i = 0; i < inputFields.length; i++) {

            //Get the value of the input fields
            var inputValue = d3.select("#" + inputFields[i].id).property("value");
            console.log(inputValue);
        
    
            //filter based on all fields
            if (inputValue.trim() !== "") {
            var filteredData = data.filter(dataInput => dataInput[inputFields[i].id] === inputValue);
            console.log(filteredData);
            };
        }; */

        //Setting a variable for the grouped JS object (by year), using the groupBy function from util.js
        var groupby_year = groupBy(filter_data, "Year");
        console.log(groupby_year);
        //Setting a variable for a empty JS object that will hold my years as main key with S and P as sub-keys with their counts as values
        //Use the countBy function from util.js to get the counts and then add to the empty JS object
        var count_by_PS_year = {};
        Object.entries(groupby_year).forEach(([key, value]) => {
            var count_by_PS = countBy(value, "StatusMission");
            count_by_PS_year[key] = count_by_PS;
        });
        console.log(count_by_PS_year);
        //Getting arrays for the graphing:
        //To get the x-axis I just need the keys from my JS object I created after my counting (which are the years)
        var x_axis = Object.keys(count_by_PS_year);
        console.log(x_axis);
        //To get the two y-axes, use the get_display_data function from util.js. 
        var y_axis_P = get_display_data(count_by_PS_year, "Success");
        var y_axis_S = get_display_data(count_by_PS_year, "Failure");
        console.log(y_axis_P);
        console.log(y_axis_S);
        //Plotly code for the private/state line graph: need two traces for two lines
        var trace1 = {
            x: x_axis,
            y: y_axis_P,
            type: 'bar',
            name: 'Sucess'
          };
          var trace2 = {
            x: x_axis,
            y: y_axis_S,
            type: 'bar',
            name: 'Failure'
          };
          var data = [trace1, trace2];
          var layout = {
            barmode: 'stack',
            title : "Global Space Launches from 1957-2020",
            xaxis: { title: "Company name" },
            yaxis: {
                range: [0, 110],
                title: "Total Launches"
            }
          };
          //var layout = {barmode: 'group'};

          Plotly.newPlot('bar', data,layout);

        var groupby_year = groupBy(filter_data, "CompanyName");
        console.log("groupby_year=", groupby_year);

        var launch_size = {};
        Object.entries(groupby_year).forEach(([key, value]) => {
            var count_by_PS = value.length;
            launch_size [key] = count_by_PS;
    
        });
        console.log("count_by_PS_year=", launch_size);
        
        //Getting arrays for the graphing:
        //To get the x-axis I just need the keys from my JS object I created after my counting (which are the years)
        var x_axis = Object.keys(launch_size);
        console.log(x_axis);
        var y_axis = Object.values(launch_size);
        console.log(y_axis);

        var trace2 = {
            x: x_axis,
            y: y_axis,
            type :'bar'
          };

        var layout2 ={
            title: "Global Space Launch Companies from 1957-2020",
            xaxis: { title: "Company name" },
            margin: { t: 30},
            yaxis: {
                range: [0, 200],
                title: "Total Launches"
            }
          };

          var data2 = [trace2];

          Plotly.newPlot("bubble", data2,layout2);
    });

};
function init() {
    // Assign the value of the dropdown menu option to a variable
    var dropdown = d3.select("#CountryofLaunch");

    countries = [];
    runs = ["S","P"];
    // Populate the drop down value using the names from data.json
    d3.json("/static/data/finaldata.json").then((data) => {

        data.map(row => {
            var country = row.CompanysCountryofOrigin

            //console.log(country);

            if(!countries.includes(country)){
                countries.push(country);
            }
        });

        console.log(runs);
        console.log(countries);

        //append each of the options to the drop down
      countries.forEach((sample) => {
        dropdown.append("option").text(sample).property("value", sample);
      });

     /*  runs.forEach((sample) => {
        dropdown1.append("option").text(sample).property("value", sample);
      }); */
      
      // Use the first sample from the list to build the initial plots
      var firstSample = countries[0];
      var firstRun = runs[0]
      //buildCharts(firstSample);
      buildCharts(firstSample);
      //otuGraphs(firstSample);
    });
};
function optionChanged(newSampleData) {
    // Fetch new data each time a new id is selected
    buildCharts(newSampleData,runs);
    console.log(newSampleData);
    //otuGraphs(newSampleData);
};

// Initialize the dashboard
init();